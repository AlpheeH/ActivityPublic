﻿namespace CrazyBooks_Utility
{
    public enum ControllerAction { Create, Delete, Details, Edit, Index }
}
